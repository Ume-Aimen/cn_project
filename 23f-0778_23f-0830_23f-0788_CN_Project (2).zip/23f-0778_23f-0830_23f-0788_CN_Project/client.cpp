//// client.cpp
//#include <bits/stdc++.h>
//#include <arpa/inet.h>
//#include <netinet/in.h>
//#include <sys/socket.h>
//#include <sys/types.h>
//#include <unistd.h>
//#include <thread>
//#include <atomic>
//using namespace std;
//
//const int TCP_PORT = 8000;
//const int UDP_PORT = 9000; // server UDP port
//const int BUF_SZ = 8192;
//
//string campus_name;
//string campus_pass;
//string server_ip = "127.0.0.1";
//int tcp_fd = -1;
//int udp_fd = -1;
//atomic<bool> running{ true };
//
//mutex inbox_mtx;
//deque<string> inbox;
//
//static inline string trim(const string& s) {
//    size_t a = 0, b = s.size();
//    while (a < b && isspace((unsigned char)s[a])) ++a;
//    while (b > a && isspace((unsigned char)s[b - 1])) --b;
//    return s.substr(a, b - a);
//}
//
//ssize_t send_all(int fd, const char* buf, size_t len) {
//    size_t sent = 0;
//    while (sent < len) {
//        ssize_t n = send(fd, buf + sent, len - sent, 0);
//        if (n <= 0) return n;
//        sent += n;
//    }
//    return (ssize_t)sent;
//}
//
//void send_tcp(const string& s) {
//    string out = s;
//    if (out.empty() || out.back() != '\n') out.push_back('\n');
//    send_all(tcp_fd, out.c_str(), out.size());
//}
//
//void safe_print(const string& s) {
//    cout << s << endl;
//}
//
//void tcp_receive_loop() {
//    string rbuf;
//    char tmp[BUF_SZ];
//    while (running) {
//        ssize_t n = recv(tcp_fd, tmp, sizeof(tmp), 0);
//        if (n < 0) {
//            // error
//            running = false;
//            break;
//        }
//        else if (n == 0) {
//            // closed
//            running = false;
//            break;
//        }
//        rbuf.append(tmp, tmp + n);
//        size_t pos;
//        while ((pos = rbuf.find('\n')) != string::npos) {
//            string line = rbuf.substr(0, pos);
//            rbuf.erase(0, pos + 1);
//            line = trim(line);
//            if (line.empty()) continue;
//            if (line.rfind("FROM:", 0) == 0 || line.rfind("BCAST;", 0) == 0) {
//                lock_guard<mutex> lg(inbox_mtx);
//                inbox.push_back(line);
//            }
//            else {
//                safe_print("SERVER: " + line);
//            }
//        }
//    }
//}
//
//void udp_receive_loop() {
//    char buf[BUF_SZ];
//    sockaddr_in src{};
//    socklen_t slen = sizeof(src);
//    while (running) {
//        ssize_t n = recvfrom(udp_fd, buf, sizeof(buf) - 1, 0, (sockaddr*)&src, &slen);
//        if (n <= 0) {
//            if (!running) break;
//            continue;
//        }
//        buf[n] = 0;
//        string s(buf);
//        lock_guard<mutex> lg(inbox_mtx);
//        inbox.push_back("UDP:" + s);
//    }
//}
//
//void heartbeat_loop() {
//    sockaddr_in srv{};
//    srv.sin_family = AF_INET;
//    srv.sin_port = htons(UDP_PORT);
//    inet_pton(AF_INET, server_ip.c_str(), &(srv.sin_addr));
//    while (running) {
//        string hb = "HB;Campus:" + campus_name;
//        sendto(udp_fd, hb.c_str(), hb.size(), 0, (sockaddr*)&srv, sizeof(srv));
//        this_thread::sleep_for(chrono::seconds(10));
//    }
//}
//
//int main(int argc, char** argv) {
//    if (argc < 3) {
//        cout << "Usage: ./client <CampusName> <Password> [server_ip]\nExample: ./client Lahore NU-LHR-123 127.0.0.1" << endl;
//        return 1;
//    }
//    campus_name = argv[1];
//    campus_pass = argv[2];
//    if (argc >= 4) server_ip = argv[3];
//
//    tcp_fd = socket(AF_INET, SOCK_STREAM, 0);
//    if (tcp_fd < 0) { perror("socket"); return 1; }
//    sockaddr_in srv{};
//    srv.sin_family = AF_INET;
//    srv.sin_port = htons(TCP_PORT);
//    inet_pton(AF_INET, server_ip.c_str(), &srv.sin_addr);
//    if (connect(tcp_fd, (sockaddr*)&srv, sizeof(srv)) < 0) {
//        perror("connect");
//        close(tcp_fd);
//        return 1;
//    }
//
//    // send auth
//    string auth = "AUTH;Campus:" + campus_name + ";Pass:" + campus_pass + "\n";
//    send_all(tcp_fd, auth.c_str(), auth.size());
//
//    // wait for single-line response
//    string rline;
//    char tmp[BUF_SZ];
//    ssize_t n = recv(tcp_fd, tmp, sizeof(tmp) - 1, 0);
//    if (n <= 0) {
//        cout << "No response from server" << endl;
//        close(tcp_fd);
//        return 1;
//    }
//    tmp[n] = 0;
//    rline = trim(string(tmp));
//    if (rline.find("AUTH_OK") == string::npos) {
//        cout << "Authentication failed: " << rline << endl;
//        close(tcp_fd);
//        return 1;
//    }
//    cout << "Authenticated as " << campus_name << endl;
//
//    // UDP socket
//    udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
//    if (udp_fd < 0) { perror("udp socket"); close(tcp_fd); return 1; }
//    sockaddr_in local{};
//    local.sin_family = AF_INET;
//    local.sin_addr.s_addr = INADDR_ANY;
//    local.sin_port = 0; // ephemeral
//    bind(udp_fd, (sockaddr*)&local, sizeof(local));
//
//    thread t_tcp(tcp_receive_loop);
//    thread t_udp(udp_receive_loop);
//    thread t_hb(heartbeat_loop);
//
//    // Main UI loop
//    while (running) {
//        cout << "\nMenu:\n1) Send message\n2) View received messages\n3) Quit\nChoice: ";
//        string choice;
//        if (!getline(cin, choice)) break;
//        choice = trim(choice);
//        if (choice == "1") {
//            cout << "Target campus: ";
//            string target; getline(cin, target);
//            cout << "Department: ";
//            string dept; getline(cin, dept);
//            cout << "Message: ";
//            string msg; getline(cin, msg);
//            target = trim(target);
//            dept = trim(dept);
//            msg = trim(msg);
//            string out = "SEND;TO:" + target + ";DEPT:" + dept + ";MSG:" + msg;
//            send_tcp(out);
//        }
//        else if (choice == "2") {
//            lock_guard<mutex> lg(inbox_mtx);
//            if (inbox.empty()) cout << "No messages." << endl;
//            else {
//                cout << "Messages:" << endl;
//                while (!inbox.empty()) {
//                    cout << inbox.front() << endl;
//                    inbox.pop_front();
//                }
//            }
//        }
//        else if (choice == "3") {
//            send_tcp("QUIT");
//            running = false;
//            break;
//        }
//        else {
//            cout << "Invalid choice" << endl;
//        }
//    }
//
//    // cleanup
//    running = false;
//    shutdown(tcp_fd, SHUT_RDWR);
//    close(tcp_fd);
//    close(udp_fd);
//
//    if (t_tcp.joinable()) t_tcp.join();
//    if (t_udp.joinable()) t_udp.detach();
//    if (t_hb.joinable()) t_hb.detach();
//
//    cout << "Client exited." << endl;
//    return 0;
//}
