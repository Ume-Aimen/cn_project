// server.cpp
#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <thread>
#include <signal.h>
#include <mutex>
using namespace std;

const int TCP_PORT = 8000;
const int UDP_PORT = 9000;
const int BACKLOG = 10;
const int BUF_SZ = 8192;

struct client_info {
    int tcp_fd = -1;
    string campus;
    sockaddr_in udp_addr{};
    bool has_udp = false;
    time_t last_seen = 0;
};

map<string, string> valid_credentials = {
    {"Lahore", "NU-LHR-123"},
    {"Karachi", "NU-KHI-123"},
    {"Peshawar", "NU-PSH-123"},
    {"CFD", "NU-CFD-123"},
    {"Multan", "NU-MTN-123"}
};

map<string, client_info> clients;
mutex clients_mtx;
atomic<bool> server_running{ true };

void print_event(const string& s) {
    time_t t = time(nullptr);
    char buf[64];
    strftime(buf, sizeof(buf), "%F %T", localtime(&t));
    cout << "[" << buf << "] " << s << endl;
}

static inline string trim(const string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace((unsigned char)s[a])) ++a;
    while (b > a && isspace((unsigned char)s[b - 1])) --b;
    return s.substr(a, b - a);
}

vector<string> split_kv(const string& s, char sep = ';') {
    vector<string> out;
    string cur;
    for (char c : s) {
        if (c == sep) {
            if (!cur.empty()) out.push_back(cur);
            cur.clear();
        }
        else cur.push_back(c);
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

string get_field(const string& s, const string& key) {
    vector<string> parts = split_kv(s);
    for (auto& p : parts) {
        size_t pos = p.find(':');
        if (pos != string::npos) {
            string k = trim(p.substr(0, pos));
            string v = trim(p.substr(pos + 1));
            if (k == key) return v;
        }
    }
    return "";
}

ssize_t send_all(int fd, const char* buf, size_t len) {
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = send(fd, buf + sent, len - sent, 0);
        if (n <= 0) return n;
        sent += n;
    }
    return (ssize_t)sent;
}

void send_tcp_message(int fd, const string& msg) {
    string out = msg;
    // ensure newline at end for client line-based parsing
    if (out.empty() || out.back() != '\n') out.push_back('\n');
    send_all(fd, out.c_str(), out.size());
}

void handle_client(int client_fd, sockaddr_in peer) {
    string peerip = inet_ntoa(peer.sin_addr);
    int peerport = ntohs(peer.sin_port);
    print_event("TCP connection from " + peerip + ":" + to_string(peerport) + " (fd=" + to_string(client_fd) + ")");
    string rbuf; // accumulate partial data
    bool authed = false;
    string campus_name;

    char tmp[BUF_SZ];
    while (server_running) {
        ssize_t n = recv(client_fd, tmp, sizeof(tmp), 0);
        if (n < 0) {
            // error
            break;
        }
        else if (n == 0) {
            // closed
            break;
        }
        rbuf.append(tmp, tmp + n);

        // process full lines
        size_t pos;
        while ((pos = rbuf.find('\n')) != string::npos) {
            string line = rbuf.substr(0, pos);
            rbuf.erase(0, pos + 1);
            line = trim(line);
            if (line.empty()) continue;

            if (!authed) {
                // Expect: AUTH;Campus:<name>;Pass:<password>
                // Allow "AUTH;" prefix or if not present still parse by fields.
                string t = get_field(line, "Campus");
                string p = get_field(line, "Pass");
                if (t.empty() || p.empty()) {
                    send_tcp_message(client_fd, "AUTH_FAIL");
                    print_event("AUTH_FAIL (bad packet) from fd=" + to_string(client_fd) + " data=[" + line + "]");
                    goto disconnect;
                }
                if (valid_credentials.count(t) && valid_credentials[t] == p) {
                    campus_name = t;
                    client_info ci;
                    ci.tcp_fd = client_fd;
                    ci.campus = campus_name;
                    ci.has_udp = false;
                    ci.last_seen = 0;
                    {
                        lock_guard<mutex> lg(clients_mtx);
                        // If an old record existed, close old fd
                        if (clients.count(campus_name) && clients[campus_name].tcp_fd != -1 && clients[campus_name].tcp_fd != client_fd) {
                            int oldfd = clients[campus_name].tcp_fd;
                            print_event("Replacing existing TCP fd for " + campus_name + " (oldfd=" + to_string(oldfd) + ")");
                            // best-effort close old socket
                            shutdown(oldfd, SHUT_RDWR);
                            close(oldfd);
                        }
                        clients[campus_name] = ci;
                    }
                    authed = true;
                    send_tcp_message(client_fd, "AUTH_OK");
                    print_event("AUTH_OK for " + campus_name + " (fd=" + to_string(client_fd) + ")");
                }
                else {
                    send_tcp_message(client_fd, "AUTH_FAIL");
                    print_event("AUTH_FAIL attempt for " + t + " (fd=" + to_string(client_fd) + ")");
                    goto disconnect;
                }
            }
            else {
                // handle commands
                // SEND;TO:<Campus>;DEPT:<Dept>;MSG:<text>
                if (line.rfind("SEND;", 0) == 0 || line.rfind("SEND", 0) == 0) {
                    string to = get_field(line, "TO");
                    string dept = get_field(line, "DEPT");
                    string msg = get_field(line, "MSG");
                    if (to.empty() || msg.empty()) {
                        send_tcp_message(client_fd, "ERR;Missing TO or MSG");
                        continue;
                    }
                    lock_guard<mutex> lg(clients_mtx);
                    if (clients.count(to) && clients[to].tcp_fd > 0) {
                        int destfd = clients[to].tcp_fd;
                        string out = "FROM:" + campus_name + ";DEPT:" + dept + ";MSG:" + msg;
                        send_tcp_message(destfd, out);
                        send_tcp_message(client_fd, "SENT");
                        print_event("Routed message from " + campus_name + " to " + to);
                    }
                    else {
                        send_tcp_message(client_fd, "ERR;TargetOffline");
                        print_event("Failed route: " + to + " offline (from " + campus_name + ")");
                    }
                }
                else if (line == "QUIT") {
                    print_event("Client QUIT received from " + campus_name);
                    goto disconnect;
                }
                else {
                    send_tcp_message(client_fd, "ERR;UnknownCmd");
                }
            }
        } // while lines available
    } // while running

disconnect:
    if (authed) {
        lock_guard<mutex> lg(clients_mtx);
        auto it = clients.find(campus_name);
        if (it != clients.end()) {
            // preserve UDP info if present, but remove tcp_fd
            it->second.tcp_fd = -1;
            // optionally keep UDP record and last_seen
        }
        print_event("Disconnected " + campus_name + " (fd=" + to_string(client_fd) + ")");
    }
    else {
        print_event("Unauthenticated connection closed (fd=" + to_string(client_fd) + ")");
    }
    shutdown(client_fd, SHUT_RDWR);
    close(client_fd);
}

void tcp_accept_loop() {
    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) { perror("socket"); return; }
    int opt = 1;
    setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(TCP_PORT);

    if (bind(listen_fd, (sockaddr*)&addr, sizeof(addr)) < 0) { perror("bind"); close(listen_fd); return; }
    if (listen(listen_fd, BACKLOG) < 0) { perror("listen"); close(listen_fd); return; }
    print_event("TCP server listening on port " + to_string(TCP_PORT));

    while (server_running) {
        sockaddr_in cli{};
        socklen_t clen = sizeof(cli);
        int client_fd = accept(listen_fd, (sockaddr*)&cli, &clen);
        if (client_fd < 0) {
            if (!server_running) break;
            perror("accept");
            continue;
        }
        thread t(handle_client, client_fd, cli);
        t.detach();
    }
    close(listen_fd);
}

void udp_listener_loop() {
    int udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_fd < 0) { perror("udp socket"); return; }
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(UDP_PORT);
    if (bind(udp_fd, (sockaddr*)&addr, sizeof(addr)) < 0) { perror("udp bind"); close(udp_fd); return; }
    print_event("UDP listener bound on port " + to_string(UDP_PORT));

    char buf[BUF_SZ];
    while (server_running) {
        sockaddr_in src{};
        socklen_t slen = sizeof(src);
        ssize_t n = recvfrom(udp_fd, buf, sizeof(buf) - 1, 0, (sockaddr*)&src, &slen);
        if (n <= 0) {
            if (!server_running) break;
            continue;
        }
        buf[n] = 0;
        string data(buf);
        data = trim(data);
        string campus = get_field(data, "Campus");
        time_t now = time(nullptr);
        if (!campus.empty()) {
            lock_guard<mutex> lg(clients_mtx);
            if (clients.count(campus)) {
                clients[campus].udp_addr = src;
                clients[campus].last_seen = now;
                clients[campus].has_udp = true;
                print_event("Heartbeat from " + campus + " (" + inet_ntoa(src.sin_addr) + ":" + to_string(ntohs(src.sin_port)) + ")");
            }
            else {
                client_info ci{};
                ci.tcp_fd = -1;
                ci.campus = campus;
                ci.udp_addr = src;
                ci.last_seen = now;
                ci.has_udp = true;
                clients[campus] = ci;
                print_event("Heartbeat (new) from " + campus + " (" + inet_ntoa(src.sin_addr) + ":" + to_string(ntohs(src.sin_port)) + ")");
            }
        }
    }
    close(udp_fd);
}

void admin_console_loop() {
    string line;
    int udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_fd < 0) { perror("admin udp socket"); return; }
    print_event("Admin console ready. Commands:\n  LIST\n  BROADCAST <message>\n  QUIT");
    while (server_running) {
        cout << "> ";
        if (!getline(cin, line)) break;
        if (!server_running) break;
        if (line.empty()) continue;
        if (line == "LIST") {
            lock_guard<mutex> lg(clients_mtx);
            cout << "Connected campuses:" << endl;
            for (auto& kv : clients) {
                string k = kv.first;
                client_info& ci = (client_info&)kv.second;
                cout << " - " << k << " | tcp_fd=" << ci.tcp_fd
                    << " | has_udp=" << (ci.has_udp ? "yes" : "no")
                    << " | last_seen=";
                if (ci.last_seen) {
                    char tb[64];
                    strftime(tb, sizeof(tb), "%F %T", localtime(&ci.last_seen));
                    cout << tb;
                }
                else cout << "N/A";
                cout << " | udp_addr=";
                if (ci.has_udp) cout << inet_ntoa(ci.udp_addr.sin_addr) << ":" << ntohs(ci.udp_addr.sin_port);
                else cout << "N/A";
                cout << endl;
            }
        }
        else if (line.rfind("BROADCAST ", 0) == 0) {
            string msg = line.substr(10);
            lock_guard<mutex> lg(clients_mtx);
            for (auto& kv : clients) {
                client_info& ci = (client_info&)kv.second;
                if (ci.has_udp) {
                    string out = "BCAST;MSG:" + msg;
                    sendto(udp_fd, out.c_str(), out.size(), 0, (sockaddr*)&ci.udp_addr, sizeof(ci.udp_addr));
                }
            }
            print_event("Broadcast sent: " + msg);
        }
        else if (line == "QUIT") {
            print_event("Admin requested quit. Server shutting down.");
            server_running = false;
            break;
        }
        else {
            cout << "Unknown command. Use LIST, BROADCAST <message>, QUIT" << endl;
        }
    }
    close(udp_fd);
}

void sigint_handler(int) {
    print_event("SIGINT received. Shutting down server.");
    server_running = false;
}

int main() {
    signal(SIGINT, sigint_handler);

    thread t_tcp(tcp_accept_loop);
    thread t_udp(udp_listener_loop);
    thread t_admin(admin_console_loop);

    t_admin.join(); // admin can request shutdown
    // ensure other loops stop
    server_running = false;

    // give threads a moment to exit cleanly
    if (t_tcp.joinable()) t_tcp.join();
    if (t_udp.joinable()) t_udp.join();

    print_event("Server exited.");
    return 0;
}

